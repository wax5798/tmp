if not vim.g.vscode then
	require("core")
end
